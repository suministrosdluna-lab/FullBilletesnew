Full Billetes — Luxury Premium Final
Frontend visual refinement: luxury membership cards, champagne selected border,
green official-rate panel, hidden payment data with reveal/copy interaction.
No Supabase credentials or backend logic were intentionally changed.
